*This tool is free not for sale (✷‿✷)*

Installation (_)

pkg update

pkg upgrade

pkg install git

pkg install python

pkg install python2

pip2 install requests

pip2 install mechanize

pip install lolcat

git clone https://github.com/Tech-ZulfiQar-MaGsi/ZFKING1

cd ZFKING

python2 zf.py

Username: Contact me
Password: Contact me
